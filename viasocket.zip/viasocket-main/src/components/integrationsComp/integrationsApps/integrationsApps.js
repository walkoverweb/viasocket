export default function IntegrationsApps() {
    return <></>;
}
