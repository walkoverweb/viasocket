export default function IntegrationsAbout() {
    return <></>;
}
