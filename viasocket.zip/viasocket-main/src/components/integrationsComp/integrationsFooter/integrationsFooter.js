export default function IntegrationFooter() {
    return <></>;
}
